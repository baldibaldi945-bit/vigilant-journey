# PortYou Studio

Offline Android app that converts **Funky Maker (.FNMM / zip / 7z / rar)** and **V-Slice** mods to **Psych Engine 1.0.4 (mobile)**. The source project is kept below 25 MiB; the built APK is not subject to that limit.

## Status
| Piece | State |
|---|---|
| UI, archive import/export, save-location memory | implemented (on-device visual tuning still recommended) |
| Funky Maker -> Psych | Kotlin converter with clean output, chart/events, character strips, stage transforms, fixed-screen objects, camera, limited icon generation, separate audio routing and runtime Lua |
| V-Slice -> Psych | Kotlin converter with charts, events, stages, NoteStyle arrow/splash atlases, Haxe-to-Lua with HScript fallback, native Adobe Animate SpriteMap characters and separate vocals |
| Animate SpriteMaps | retained as native `Animation.json` + spritemap page JSON/PNG; multi-atlas folders are combined at JSON/page level without rasterizing or cutting the art |
| Audio | copied byte-for-byte into separate `Inst.ogg`, `Voices-Player.ogg`, `Voices-Opponent.ogg` files; no mixing/FFmpeg stage |
| Script library | compressed Lua library includes general scripts from the supplied script collection; events and note types remain embedded |

**Important limits:** Character placement and some animation offsets may still need a final adjustment in the Psych Engine editor. Exact gameplay equivalence for every custom event, Haxe API or shader is not guaranteed. HScript fallback requires `HSCRIPT_ALLOWED`, and video playback requires `VIDEOS_ALLOWED` in the target Psych build. Android build and gameplay testing are still required before treating this as a finished release.

## Build
Use the GitHub **Build APK** workflow or locally run `gradle :app:assembleRelease` with JDK 17 and Android SDK 34. The workflow checks that the checked-out source files remain below 25 MiB, but it does not reject an APK for exceeding 25 MiB.

## Source tools
- `tools/prepare_assets.py` — regenerates the UI artwork assets.
- `tools/fnmm_to_psych.py` and `tools/vslice_to_psych.py` — legacy Python experiments/diagnostics. The Android app uses the Kotlin implementation under `app/src/main/java` and bundled runtime assets under `app/src/main/assets`; these are the production source of truth.

## Credits
App by axelzerox023 — [YouTube](https://youtube.com/@axelzerox023) · [Instagram](https://www.instagram.com/axelzerox023)

Friend: [Akram](https://youtube.com/@akrammakak-official)
