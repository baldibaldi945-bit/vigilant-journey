package com.portyou.studio.convert

/**
 * Brain v2 - works out what a custom event / note type DOES and writes Psych Engine 1.0 Lua for it.
 * Evidence, strongest first:
 *   1. the original source (Lua or Haxe): real API calls and their literal arguments
 *   2. how the chart USES it: value shapes of every event row; side / count of every note
 *   3. the name: split into words (English, Spanish, Portuguese), also glued names (slowzoom, multsv)
 * Every generated callback is wrapped in pcall so a wrong guess can never crash a song. Rule based, offline.
 * Reference implementation + corpus test: tools/portyou/brain.py (449 real kinds, 0 invalid Lua).
 */
object Brain {
    /** how the chart uses one note kind */
    class NoteUsage(val count: Int = 0, val player: Int = 0, val opp: Int = 0, val sustain: Int = 0)

    // ------------------------------------------------------------------ vocabulary
    private val VOCAB: Map<String, List<String>> = mapOf(
        "flash" to listOf("flash", "flashes", "flashing", "destello", "relampago", "flashbang"),
        "shake" to listOf("shake", "shaking", "earthquake", "rumble", "vibrate", "tremor", "temblor", "sacudir", "kaboom"),
        "zoom" to listOf("zoom", "bump", "boom", "bounce", "pulse", "camzoom", "acercar"),
        "fade" to listOf("fade", "fadeout", "blackout", "darken", "darkness", "oscuro", "apagar", "dim", "dark"),
        "hud" to listOf("hud", "ui", "gui", "interface", "hidehud", "showhud"),
        "anim" to listOf("anim", "animation", "animacion", "playanim", "play"),
        "hey" to listOf("hey", "cheer"),
        "follow" to listOf("focus", "follow", "forced", "camerapos", "campos", "camfollow"),
        "bop" to listOf("modulo", "bopping", "bumpmodulo", "bopspeed"),
        "call" to listOf("hscript", "call"),
        "speed" to listOf("speed", "scrollspeed", "velocidad"),
        "char" to listOf("changechar", "switchchar", "swapchar", "transformation", "personaje", "character"),
        "text" to listOf("text", "lyrics", "lyric", "subtitle", "subtitles", "caption", "dialogue", "say", "letra"),
        "angle" to listOf("rotate", "angle", "spin", "speen", "tilt", "giro", "rotar"),
        "bpm" to listOf("bpm", "tempo"),
        "shader" to listOf("chroma", "shader", "glitch", "vhs", "blur", "drunk", "bloom", "mosaic", "pixelate", "saturation",
            "contrast", "vignette", "grayscale", "filter", "effect"),
        "sound" to listOf("sound", "sfx", "audio", "sonido"),
        "jump" to listOf("jump", "hop", "fly", "float", "levitate", "salto", "volar"),
        "move" to listOf("move", "slide", "shift", "teleport", "dash", "mover", "walk"),
        "dodge" to listOf("dodge", "avoid", "qte", "space", "spacebar", "parry", "esquivar", "pistola", "dispar", "shoot"),
        "lives" to listOf("lives", "life", "revive", "vidas", "extralife"),
        "icon" to listOf("icon", "icono"),
        "visible" to listOf("show", "hide", "appear", "disappear", "spawn", "remove", "toggle", "visibility", "visible", "aparece"),
        "video" to listOf("video", "cutscene", "chromavideo"),
        "bars" to listOf("bars", "cinematic", "cinema", "cine", "letterbox"),
        "stagezoom" to listOf("stagezoom", "defaultzoom", "zoomadjust"),
        "strums" to listOf("strum", "strums", "arrows", "arrow", "middlescroll", "notes")
    )
    private val STEMS: List<String> = VOCAB.values.flatten().filter { it.length >= 4 }.distinct().sortedByDescending { it.length }

    fun words(name: String): Set<String> {
        val s = name.replace(Regex("([a-z0-9])([A-Z])"), "$1 $2")
        val out = s.lowercase().split(Regex("[^a-z0-9]+")).filter { it.isNotEmpty() }.toMutableSet()
        val low = name.lowercase().replace(Regex("[^a-z0-9]"), "")
        for (st in STEMS) if (low.contains(st)) out.add(st)
        return out
    }

    private fun nameIntents(name: String): Set<String> {
        val ws = words(name)
        return VOCAB.filter { (_, vs) -> vs.any { it in ws } }.keys
    }

    // ------------------------------------------------------------------ source evidence (Lua / Haxe)
    private val SRC_RULES: List<Pair<String, Regex>> = listOf(
        "flash" to Regex("""cameraFlash|camera\.flash|\.flash\(|FlxG\.camera\.flash|screenFlash"""),
        "shake" to Regex("""cameraShake|\.shake\(|camera\.shake"""),
        "zoom" to Regex("""doTweenZoom|defaultCamZoom|camGame\.zoom|cameraZoom|camZooming"""),
        "fade" to Regex("""cameraFade|\.fade\(|doTweenAlpha\([^)]*(black|fade)"""),
        "hud" to Regex("""camHUD\.alpha|camHUD.visible|hideHud|healthBar\.visible|setProperty\(['"]camHUD"""),
        "anim" to Regex("""playAnim|characterPlayAnim|animation\.play|playAnimation|objectPlayAnimation"""),
        "follow" to Regex("""cameraSetTarget|camFollow|isCameraOnForcedPos|moveCamera"""),
        "speed" to Regex("""songSpeed|scrollSpeed|noteTween"""),
        "char" to Regex("""changeCharacter|addCharacterToList|Change Character"""),
        "text" to Regex("""makeLuaText|setTextString|FlxText"""),
        "angle" to Regex("""doTweenAngle|\.angle\b"""),
        "bpm" to Regex("""Conductor\.bpm|changeBPM|setBPM"""),
        "shader" to Regex("""initLuaShader|createRuntimeShader|setSpriteShader|ShaderFilter"""),
        "sound" to Regex("""playSound|FlxG\.sound|FunkinSound"""),
        "dodge" to Regex("""keyJustPressed|keyboardJustPressed|FlxG\.keys\.justPressed|justPressed"""),
        "lives" to Regex("""function onGameOver|onGameOver\b"""),
        "icon" to Regex("""iconP[12]|changeIcon|healthIcon"""),
        "visible" to Regex("""\.visible|removeLuaSprite|addLuaSprite"""),
        "video" to Regex("""startVideo|FlxVideo|VideoSprite"""),
        "strums" to Regex("""strumLineNotes|opponentStrums|playerStrums|noteTween[XYA]"""),
        "move" to Regex("""doTweenX|doTweenY|setProperty\(['"](boyfriend|dad|gf)\.[xy]"""),
        "circle" to Regex("""math\.(sin|cos)|Math\.(sin|cos)""")
    )

    private fun sourceIntents(src: String?): Set<String> =
        if (src.isNullOrEmpty()) emptySet() else SRC_RULES.filter { it.second.containsMatchIn(src) }.map { it.first }.toSet()

    private fun srcNumber(src: String?, rx: String, def: Double): Double =
        Regex(rx, RegexOption.IGNORE_CASE).find(src ?: "")?.groupValues?.getOrNull(1)?.toDoubleOrNull() ?: def

    /** keys the original listens for: keyJustPressed('space') / FlxG.keys.justPressed.SPACE */
    private fun srcKeys(src: String?): Set<String> {
        val t = src ?: return emptySet()
        val ks = LinkedHashSet<String>()
        Regex("""keyJustPressed\(\s*['"]([A-Za-z0-9_]+)['"]""").findAll(t).forEach { ks.add(it.groupValues[1].lowercase()) }
        Regex("""keyboardJustPressed\(\s*['"]([A-Za-z0-9_]+)['"]""").findAll(t).forEach { ks.add(it.groupValues[1].lowercase()) }
        Regex("""justPressed\.([A-Z0-9_]+)""").findAll(t).forEach { ks.add(it.groupValues[1].lowercase()) }
        return ks
    }

    // ------------------------------------------------------------------ usage evidence (the chart)
    private val HEX = Regex("^#?[0-9a-fA-F]{6}$")
    private val NUM = Regex("^-?\\d+(\\.\\d+)?$")
    private val BOOLS = setOf("true", "false", "on", "off", "yes", "no", "1", "0")
    private val CHARS = setOf("bf", "boyfriend", "dad", "opponent", "gf", "girlfriend", "player", "dad2", "bf2")
    private val EASE = Regex("^(linear|quad|cube|quart|quint|sine|expo|circ|back|elastic|bounce|smooth|smoother)(in|out|inout)?$", RegexOption.IGNORE_CASE)

    /** classify one event value */
    fun shape(v0: String?): String {
        val v = (v0 ?: "").trim()
        if (v.isEmpty()) return "empty"
        if (v.startsWith("{") && v.endsWith("}")) return "json"
        if (v.contains(",")) {
            val sh = v.split(",").map { shape(it.trim()) }
            return if (sh.all { it == "num" || it == "bool" || it == "ease" }) "csv:" + sh.joinToString("/") else "csv"
        }
        if (NUM.matches(v)) return "num"
        if (v.lowercase() in BOOLS) return "bool"
        if (v.lowercase() in CHARS) return "char"
        if (HEX.matches(v)) return "hex"
        if (EASE.matches(v)) return "ease"
        return "str"
    }

    private fun topShape(values: List<String>): String =
        values.map { shape(it) }.groupingBy { it }.eachCount().maxByOrNull { it.value }?.key ?: ""

    private fun usageIntents(samples: List<Pair<String, String>>?): Map<String, String> {
        val out = LinkedHashMap<String, String>()
        if (samples.isNullOrEmpty()) return out
        val top1 = topShape(samples.map { it.first })
        val top2 = topShape(samples.map { it.second })
        if (top1 == "hex") out["flash"] = "value1 is a colour"
        if (top1 == "char" || top2 == "char") out["follow"] = "a character is named"
        if (top1 == "bool" && (top2 == "char" || top2 == "empty")) out["follow"] = "bool + character = forced camera target"
        if (top1.startsWith("csv:bool") || top1.startsWith("csv:num")) out["shader"] = "comma list of bool/numbers (effect settings)"
        if (top1 == "json") out["json"] = "json payload"
        if (top1 == "str") {
            val sent = samples.count { it.first.trim().contains(" ") || it.first.trim().length > 14 }
            if (sent * 2 >= samples.size) out["text"] = "sentences" else out["name_arg"] = "single words (an id / function name / file)"
        }
        return out
    }

    // ------------------------------------------------------------------ shader pick
    /** which .frag of the mod does this effect name point at? (Bloom Effect -> bloom.frag) */
    fun fragFor(kind: String, shaders: Collection<String>?): String? {
        val skip = setOf("effect", "event", "toggle", "screen", "camera")
        val ws = kind.replace(Regex("([a-z0-9])([A-Z])"), "$1 $2").lowercase().split(Regex("[^a-z0-9]+")).filter { it.isNotEmpty() && it !in skip }
        val low = kind.lowercase().replace(Regex("[^a-z0-9]"), "")
        val bad = listOf("glitch", "clip", "copy", "old")
        var best: String? = null
        fun baseOf(s: String) = s.lowercase().removeSuffix(".frag").replace(Regex("[^a-z0-9]"), "")
        for (sh in shaders ?: emptyList()) {
            val base = baseOf(sh)
            if (bad.any { it in base } && bad.none { it in low }) continue
            val hit = ws.any { w -> w == base || (w.length > 3 && base.startsWith(w)) || (w.length > 5 && base.contains(w)) } || (base.length > 4 && low.contains(base))
            if (hit && (best == null || base.length < baseOf(best).length)) best = sh
        }
        return best
    }

    // ------------------------------------------------------------------ Lua writers
    private fun n(d: Double) = if (d == Math.floor(d) && Math.abs(d) < 1e9) d.toLong().toString() else d.toString()
    private fun q(s: String) = "'" + s.replace("\\", "\\\\").replace("'", "\\'") + "'"
    private fun ident(s: String) = s.replace(Regex("\\W"), "_").ifEmpty { "x" }

    private const val PV = """local function pv(s, k, d) if s == nil then return d end local v = string.match(tostring(s), k .. '=([^;]+)') if v ~= nil then return tonumber(v) or v end return tonumber(s) or d end
local function csv(s) local t = {} for x in string.gmatch(tostring(s or ''), '[^,]+') do t[#t + 1] = (x:gsub('^%s+', ''):gsub('%s+$', '')) end return t end
local function tcol(s) s = tostring(s or ''):gsub('#', '') if #s == 6 then return s end return 'FFFFFF' end
"""

    /** Psych 1.0 custom event (custom_events/<kind>.lua). value1/value2 are the two event fields.
     *  [samples] = every (value1, value2) the charts use it with, [shaders] = *.frag files of the mod. Returns lua to explanation. */
    fun synthEvent(kind: String, hx: String?, samples: List<Pair<String, String>>? = null, shaders: Collection<String>? = null): Pair<String, String> {
        val r = synthEventFull(kind, hx, samples, shaders)
        return r.first to r.second
    }

    fun synthEventFull(kind: String, hx: String?, samples: List<Pair<String, String>>?, shaders: Collection<String>?): Triple<String, String, Double> {
        // Known Haxe event from the user's Marvin report. This mirrors its regular/custom
        // zoom modes instead of letting the generic name classifier emit an empty event.
        val eventKey = kind.lowercase().replace(Regex("[^a-z0-9]"), "")
        if (eventKey == "marvinoustween") return marvinousTweenEvent(kind)

        val ev = LinkedHashMap<String, String>()
        for (i in sourceIntents(hx)) ev[i] = "source"
        for ((i, why) in usageIntents(samples)) if (i !in ev) ev[i] = "chart: $why"
        for (i in nameIntents(kind)) if (i !in ev) ev[i] = "name"
        val keys = srcKeys(hx)
        val dur = srcNumber(hx, "(?:duration|time|length)\\D{0,12}([0-9]*\\.?[0-9]+)", 0.5)
        val power = srcNumber(hx, "(?:intensity|amount|power|strength)\\D{0,12}([0-9]*\\.?[0-9]+)", 0.02)
        val shape1 = if (samples.isNullOrEmpty()) "" else topShape(samples.map { it.first })
        if (ev.containsKey("circle") && !ev.containsKey("angle")) ev["angle"] = ev["circle"]!!
        ev.remove("circle")
        if (ev.containsKey("video")) { ev.remove("shader"); ev.remove("text") }
        if (ev.containsKey("stagezoom")) { ev.remove("zoom"); ev.remove("shader") }
        if (ev.containsKey("bop")) { ev.remove("zoom"); ev.remove("follow") }
        if (ev.containsKey("call")) for (x in listOf("text", "zoom", "follow", "shader")) ev.remove(x)
        val frag = if (ev.containsKey("shader")) fragFor(kind, shaders) else null
        if (kind.lowercase() in setOf("", "a", "d", "h", "b")) ev.clear()
        val keep = ev.keys.toSet()
        val id = ident(kind)

        val pre = StringBuilder()
        val body = StringBuilder()
        fun f(s: String) { body.append("\tpcall(function() ").append(s).append(" end)\n") }

        if ("shader" in keep && frag != null) {
            val base = frag.removeSuffix(".frag")
            pre.append("local function fxOn(on)\n\tif not shadersEnabled then return end\n\tif on then\n")
            pre.append("\t\tif not luaSpriteExists('pyFx') then makeLuaSprite('pyFx') setSpriteShader('pyFx', ${q(base)}) end\n")
            pre.append("\t\trunHaxeCode([[ game.camGame.setFilters([new ShaderFilter(game.getLuaObject('pyFx').shader)]); ]])\n")
            pre.append("\telse\n\t\trunHaxeCode([[ game.camGame.setFilters([]); ]])\n\tend\nend\n")
            f("local a = csv(value1) fxOn(a[1] == 'true' or a[1] == '1' or a[1] == 'on')")
        } else if ("shader" in keep) {
            body.append("\tdebugPrint('[PortYou] \"${kind.replace("'", "")}\": the mod has no matching shader file, effect skipped')\n")
        }
        if ("stagezoom" in keep) f("local a = csv(value2) local z = tonumber(a[1]) or tonumber(value1) if z ~= nil then setProperty('defaultCamZoom', z) doTweenZoom('pyStageZoom', 'camGame', z, tonumber(a[2]) or 1, 'sineOut') end")
        if ("bop" in keep) f("pyBopEvery = tonumber(value1) or 4 pyBopAmt = tonumber(value2) or 1")
        if ("call" in keep) f("callOnLuas(tostring(value1), {tostring(value2)})")
        if ("flash" in keep) {
            val col = if (shape1 == "hex") "tcol(value1)" else "'FFFFFF'"
            val dd = if (shape1 == "hex") "tonumber(value2) or ${n(dur)}" else "pv(value1, 'duration', ${n(dur)})"
            f("cameraFlash('camGame', $col, $dd, true)")
        }
        if ("shake" in keep) f("cameraShake('camGame', pv(value1, 'intensity', ${n(power)}), pv(value2, 'duration', ${n(dur)}))")
        if ("zoom" in keep && shape1 != "json")
            f("local z = tonumber(value1) if z == nil then z = pv(value1, 'zoom', getProperty('defaultCamZoom')) end if z > 3 then z = z * 0.01 end doTweenZoom('pyZoom', 'camGame', z, tonumber(value2) or ${n(dur)}, 'quadOut')")
        if ("fade" in keep) f("cameraFade('camGame', '000000', pv(value1, 'duration', ${n(dur)}), false)")
        if ("hud" in keep) f("doTweenAlpha('pyHud', 'camHUD', pv(value1, 'alpha', 0), pv(value2, 'duration', ${n(dur)}), 'linear')")
        if ("anim" in keep) f("characterPlayAnim(tostring(pv(value2, 'target', 'boyfriend')), tostring(pv(value1, 'anim', 'idle')), true)")
        if ("hey" in keep) f("triggerEvent('Hey!', value1 or 'Both', value2 or '0.6')")
        if ("follow" in keep) f("local who = string.lower(tostring(value2 or '')) if who == '' then who = string.lower(tostring(value1 or '')) end " +
            "if who == 'dad' or who == 'opponent' then triggerEvent('Camera Follow Pos', '', '') setProperty('isCameraOnForcedPos', false) callMethod('moveCamera', {true}) " +
            "elseif who == 'gf' or who == 'girlfriend' then callMethod('moveCamera', {'gf'}) " +
            "elseif who == 'bf' or who == 'boyfriend' or who == 'player' then callMethod('moveCamera', {false}) " +
            "else triggerEvent('Camera Follow Pos', tostring(pv(value1, 'x', '')), tostring(pv(value2, 'y', ''))) end")
        if ("speed" in keep) f("triggerEvent('Change Scroll Speed', tostring(pv(value1, 'speed', tonumber(value1) or 1)), tostring(pv(value2, 'duration', tonumber(value2) or 1)))")
        if ("char" in keep) f("triggerEvent('Change Character', tostring(value1), tostring(value2))")
        if ("angle" in keep) f("doTweenAngle('pyAngle', 'camGame', pv(value1, 'angle', 15), tonumber(value2) or ${n(dur)}, 'quadOut')")
        if ("sound" in keep) f("playSound(tostring(value1), tonumber(value2) or 1)")
        if ("text" in keep) f("makeLuaText('pyText', tostring(value1), 900, 190, 560) setTextSize('pyText', 36) setObjectCamera('pyText', 'camHUD') addLuaText('pyText') runTimer('pyTextOff', ${n(maxOf(dur, 2.0))})")
        if ("video" in keep) f("startVideo(tostring(value1))")
        if ("bars" in keep) f("local on = tostring(value1) ~= 'false' and tostring(value1) ~= '0' " +
            "if not luaSpriteExists('pyBarT') then " +
            "makeLuaSprite('pyBarT', nil, 0, -120) makeGraphic('pyBarT', screenWidth, 120, '000000') setObjectCamera('pyBarT', 'camHUD') addLuaSprite('pyBarT', true) " +
            "makeLuaSprite('pyBarB', nil, 0, screenHeight) makeGraphic('pyBarB', screenWidth, 120, '000000') setObjectCamera('pyBarB', 'camHUD') addLuaSprite('pyBarB', true) end " +
            "doTweenY('pyBarT', 'pyBarT', on and 0 or -120, 0.6, 'quadOut') doTweenY('pyBarB', 'pyBarB', on and screenHeight - 120 or screenHeight, 0.6, 'quadOut')")
        if ("bpm" in keep) f("setProperty('songSpeed', getProperty('songSpeed'))")
        if ("icon" in keep) f("callMethod('iconP2.changeIcon', {tostring(value1)})")
        if ("visible" in keep) f("local o = tostring(value1) local off = tostring(value2) == '0' or tostring(value2) == 'false' setProperty(o .. '.visible', not off)")
        if ("jump" in keep) f("local who = tostring(pv(value2, 'target', 'boyfriend')) local y0 = getProperty(who .. '.y') pyJumpWho = who pyJumpY = y0 " +
            "doTweenY('pyJumpUp', who, y0 - pv(value1, 'height', 200), ${n(dur / 2)}, 'quadOut') runTimer('pyJumpBack', ${n(dur / 2)})")
        if ("move" in keep && "jump" !in keep) f("local who = tostring(pv(value2, 'target', 'boyfriend')) pyMoveWho = who pyMoveX = getProperty(who .. '.x') pyMoveY = getProperty(who .. '.y') " +
            "doTweenX('pyMoveX', who, pyMoveX + pv(value1, 'x', 0), ${n(dur)}, 'sineInOut') doTweenY('pyMoveY', who, pyMoveY + pv(value1, 'y', 0), ${n(dur)}, 'sineInOut') " +
            "if string.find(tostring(value1), 'back=1') then runTimer('pyMoveBack', ${n(dur + 0.5)}) end")
        if ("dodge" in keep) f("pyDodgeOpen = true pyDodgeHit = false runTimer('pyDodgeEnd', pv(value1, 'window', ${n(maxOf(dur, 0.6))}))")
        if ("lives" in keep) f("pyLives = (pyLives or 0) + pv(value1, 'lives', 1)")
        if (body.isEmpty()) body.append("\t-- No safe built-in equivalent was identified; see the PortYou conversion report.\n")

        val b = StringBuilder()
        b.append("-- generated by PortYou Brain v2 for \"${kind.replace("\"", "")}\"\n").append(PV).append(pre)
        b.append("local function on_$id(value1, value2)\n").append(body).append("end\n")
        b.append("function onEvent(name, value1, value2)\n\tif name == ${q(kind)} then on_$id(value1, value2) end\nend\n")
        val tc = StringBuilder()
        if ("text" in keep) tc.append("\tif tag == 'pyTextOff' then removeLuaText('pyText', true) end\n")
        if ("jump" in keep) tc.append("\tif tag == 'pyJumpBack' and pyJumpWho then doTweenY('pyJumpDown', pyJumpWho, pyJumpY, ${n(dur / 2)}, 'quadIn') end\n")
        if ("move" in keep && "jump" !in keep) tc.append("\tif tag == 'pyMoveBack' and pyMoveWho then doTweenX('pyMoveX2', pyMoveWho, pyMoveX, ${n(dur)}, 'sineInOut') doTweenY('pyMoveY2', pyMoveWho, pyMoveY, ${n(dur)}, 'sineInOut') end\n")
        if ("dodge" in keep) tc.append("\tif tag == 'pyDodgeEnd' then if pyDodgeOpen and not pyDodgeHit then setProperty('health', getProperty('health') - 0.4) end pyDodgeOpen = false end\n")
        if (tc.isNotEmpty()) b.append("function onTimerCompleted(tag)\n").append(tc).append("end\n")
        if ("dodge" in keep) {
            val kk = keys.ifEmpty { setOf("space") }
            val cond = kk.joinToString(" or ") { "keyJustPressed(${q(it.lowercase())})" }
            b.append("function onUpdate(e) if pyDodgeOpen and ($cond or mouseClicked('left')) then pyDodgeHit = true end end\n")
        }
        if ("bop" in keep) b.append("function onBeatHit() if pyBopEvery and pyBopEvery > 0 and curBeat % math.max(1, math.floor(pyBopEvery)) == 0 then setProperty('camGame.zoom', getProperty('camGame.zoom') + 0.015 * (pyBopAmt or 1)) setProperty('camHUD.zoom', getProperty('camHUD.zoom') + 0.03 * (pyBopAmt or 1)) end end\n")
        if ("lives" in keep) b.append("function onGameOver() if (pyLives or 0) > 0 then pyLives = pyLives - 1 setProperty('health', 1) return Function_Stop end return Function_Continue end\n")
        val conf = when {
            ev.values.any { it == "source" } -> 0.9
            ev.values.any { it.startsWith("chart") } -> 0.7
            ev.isNotEmpty() -> 0.5
            else -> 0.0
        }
        val why = ev.keys.sorted().joinToString(", ") { "$it(${ev[it]!!.substringBefore(':')})" }.ifEmpty { "no known behaviour" }
        return Triple(b.toString(), why, conf)
    }


    private fun marvinousTweenEvent(kind: String): Triple<String, String, Double> {
        val eventName = q(kind)
        val code = """-- PortYou: faithful mapping of MarvinousTween.hxc (regular/custom modes)
local function pyMarvinousTween(value1, value2)
    local mode = string.lower(tostring(value1 or ''))
    local target, duration, ease
    if mode == 'regular' then
        target = tonumber(value2)
        duration = 0.3
        ease = 'cubeOut'
    elseif mode == 'custom' then
        local parts = {}
        for part in string.gmatch(tostring(value2 or ''), '[^,]+') do
            parts[#parts + 1] = string.match(part, '^%s*(.-)%s*$')
        end
        if #parts < 3 then return end
        target = tonumber(parts[1])
        if target == nil or target ~= target then target = 1.0 end
        duration = tonumber(parts[2])
        if duration == nil or duration ~= duration then duration = 0.5 end
        local easeMap = {
            linear='linear',
            sinein='sineIn', sineout='sineOut', sineinout='sineInOut',
            quadin='quadIn', quadout='quadOut', quadinout='quadInOut',
            cubicin='cubeIn', cubicout='cubeOut', cubicinout='cubeInOut',
            quartin='quartIn', quartout='quartOut', quartinout='quartInOut',
            quintin='quintIn', quintout='quintOut', quintinout='quintInOut',
            expoin='expoIn', expoout='expoOut', expoinout='expoInOut',
            circin='circIn', circout='circOut', circinout='circInOut',
            backin='backIn', backout='backOut', backinout='backInOut',
            bouncein='bounceIn', bounceout='bounceOut', bounceinout='bounceInOut',
            elasticin='elasticIn', elasticout='elasticOut', elasticinout='elasticInOut'
        }
        ease = easeMap[string.lower(parts[3])] or 'linear'
    else
        return
    end
    if target == nil or target ~= target then return end
    doTweenZoom('marvinousTweenZoom', 'camGame', target, duration, ease)
end

function onEvent(name, value1, value2)
    if name == $eventName then
        pyMarvinousTween(value1, value2)
    end
end
"""
        return Triple(code, "regular/custom zoom tween mapped from the supplied Haxe implementation", 1.0)
    }

    // ------------------------------------------------------------------ note types
    private val NOTE_WORDS: Map<String, List<String>> = mapOf(
        "harmful" to listOf("hurt", "mine", "poison", "bomb", "death", "skull", "spike", "fire", "warning", "danger", "drain", "damage",
            "kill", "trap", "knife", "bullet", "static", "bone", "noscope", "explosion", "sword", "hell", "glitch"),
        "heal" to listOf("heal", "health", "medkit", "potion", "heart", "regen", "life", "drop"),
        "alt" to listOf("alt"),
        "hey" to listOf("hey", "cheer"),
        "noanim" to listOf("noanim", "noanimation", "ghost", "hidden", "invis", "phantom"),
        "second" to listOf("opponent2", "opponent3", "opponent4", "opponent5", "plr2", "plr3", "third", "second", "duet", "both", "dad2", "bf2"),
        "gf" to listOf("gf", "girlfriend")
    )

    /** Psych 1.0 custom note type (custom_notetypes/<kind>.lua). [usage] = how the charts use it, [anims] = animation names of the song's characters. */
    fun synthNote(kind: String, hx: String?, usage: NoteUsage? = null, anims: Collection<String>? = null): Pair<String, String> {
        val r = synthNoteFull(kind, hx, usage, anims)
        return r.first to r.second
    }

    fun synthNoteFull(kind: String, hx: String?, usage: NoteUsage?, anims: Collection<String>?): Triple<String, String, Double> {
        val low = kind.lowercase().replace(Regex("[^a-z0-9]"), "")
        val ws = words(kind)
        fun hit(k: String) = NOTE_WORDS[k]!!.any { low.contains(it) }
        var harmful = hit("harmful"); val heal = hit("heal"); val alt = hit("alt"); val hey = hit("hey")
        val noAnim = hit("noanim"); val second = hit("second"); val gf = hit("gf")
        val ev = sourceIntents(hx)
        val keys = srcKeys(hx)
        var dmg = srcNumber(hx, "(?:damage|health|drain)\\D{0,14}([0-9]*\\.?[0-9]+)", if (harmful) 0.4 else 0.2)
        if (dmg > 1.0) dmg /= 100.0
        // the chart tells the side: a kind used only by the opponent is a sing-style note, never a damage note
        if (usage != null && usage.count > 0 && usage.player == 0 && usage.opp > 0 && harmful && ("knife" !in ws && "bullet" !in ws)) harmful = false
        // does a character animation carry this kind's name?  kind "ugh" + anim "singUP-ugh"
        var suffix: String? = null
        for (a in anims ?: emptyList()) {
            val la = a.lowercase()
            if (la.contains("-") && la.substringAfter("-").replace(Regex("[^a-z0-9]"), "") == low) { suffix = "-" + la.substringAfter("-"); break }
        }
        val k = q(kind)
        val reasons = ArrayList<String>()
        val spawn = ArrayList<String>(); val good = ArrayList<String>(); val opp = ArrayList<String>()
        if (harmful) {
            spawn.add("setPropertyFromGroup('notes', id, 'ignoreNote', getPropertyFromGroup('notes', id, 'mustPress'))")
            good.add("setProperty('health', getProperty('health') - ${n(dmg)})"); reasons.add("damaging")
        }
        if (heal) { good.add("setProperty('health', getProperty('health') + ${n(dmg)})"); reasons.add("healing") }
        if (alt) { spawn.add("setPropertyFromGroup('notes', id, 'animSuffix', '-alt')"); reasons.add("alt anim") }
        if (suffix != null) { spawn.add("setPropertyFromGroup('notes', id, 'animSuffix', ${q(suffix)})"); reasons.add("anim suffix $suffix") }
        if (noAnim) { spawn.add("setPropertyFromGroup('notes', id, 'noAnimation', true)"); reasons.add("no anim") }
        if (hey) { good.add("characterPlayAnim('boyfriend', 'hey', true) setProperty('boyfriend.specialAnim', true)"); reasons.add("hey") }
        if (second || gf) {
            if ("both" !in low) spawn.add("setPropertyFromGroup('notes', id, 'noAnimation', true)")
            opp.add("playAnim('gf', ({'singLEFT', 'singDOWN', 'singUP', 'singRIGHT'})[noteData % 4 + 1], true) setProperty('gf.holdTimer', 0)")
            good.add("playAnim('gf', ({'singLEFT', 'singDOWN', 'singUP', 'singRIGHT'})[noteData % 4 + 1], true) setProperty('gf.holdTimer', 0)")
            reasons.add("extra character sings")
        }
        if ("dodge" in ev || keys.isNotEmpty()) {
            good.add("if keyJustPressed('space') then playAnim('boyfriend', 'dodge', true) setProperty('boyfriend.specialAnim', true) end"); reasons.add("dodge key")
        }
        val b = StringBuilder("-- generated by PortYou Brain v2 for note kind \"${kind.replace("\"", "")}\"\n")
        b.append("function onSpawnNote(id, noteData, noteType, isSustainNote)\n\tif noteType == $k then\n")
        spawn.forEach { b.append("\t\tpcall(function() $it end)\n") }
        b.append("\tend\nend\n")
        b.append("function goodNoteHit(id, noteData, noteType, isSustainNote)\n\tif noteType == $k then\n")
        good.forEach { b.append("\t\tpcall(function() $it end)\n") }
        b.append("\tend\nend\n")
        if (opp.isNotEmpty()) {
            b.append("function opponentNoteHit(id, noteData, noteType, isSustainNote)\n\tif noteType == $k then\n")
            opp.forEach { b.append("\t\tpcall(function() $it end)\n") }
            b.append("\tend\nend\n")
        }
        val conf = if (ev.isNotEmpty()) 0.9 else if (usage != null) 0.7 else if (reasons.isNotEmpty()) 0.5 else 0.0
        return Triple(b.toString(), reasons.joinToString(",").ifEmpty { "no known behaviour - plain note type" }, conf)
    }
}
