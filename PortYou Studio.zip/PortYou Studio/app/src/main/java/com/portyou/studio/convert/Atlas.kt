package com.portyou.studio.convert

import android.graphics.BitmapFactory
import org.json.JSONObject
import java.io.File

/** Lightweight metadata helpers. Adobe Animate SpriteMaps are kept native and are never rasterized. */
object Atlas {
    fun loadJson(f: File): JSONObject = JSONObject(f.readText().removePrefix("\uFEFF"))


    private data class Matrix2D(val a: Double = 1.0, val b: Double = 0.0, val c: Double = 0.0,
                                val d: Double = 1.0, val tx: Double = 0.0, val ty: Double = 0.0)

    private fun matrixOf(o: JSONObject): Matrix2D {
        val mx = o.optJSONArray("MX")
        if (mx != null && mx.length() >= 6) return Matrix2D(mx.optDouble(0, 1.0), mx.optDouble(1), mx.optDouble(2), mx.optDouble(3, 1.0), mx.optDouble(4), mx.optDouble(5))
        val m3d = o.optJSONArray("M3D")
        if (m3d != null && m3d.length() >= 14) return Matrix2D(m3d.optDouble(0, 1.0), m3d.optDouble(1), m3d.optDouble(4), m3d.optDouble(5, 1.0), m3d.optDouble(12), m3d.optDouble(13))
        return Matrix2D()
    }

    private fun multiply(p: Matrix2D, c: Matrix2D) = Matrix2D(
        p.a * c.a + p.c * c.b, p.b * c.a + p.d * c.b,
        p.a * c.c + p.c * c.d, p.b * c.c + p.d * c.d,
        p.a * c.tx + p.c * c.ty + p.tx, p.b * c.tx + p.d * c.ty + p.ty
    )

    /**
     * Determine the actual visible bounds of an Adobe Animate atlas by walking its symbol
     * timelines and combining sprite rectangles with the exported transforms. This avoids
     * treating AnimateAtlas characters as 0x0 when there is no Sparrow XML.
     */
    fun animateAtlasSize(folder: File): Pair<Double, Double>? {
        val animationFile = File(folder, "Animation.json")
        if (!animationFile.isFile) return null
        return try {
            val animation = loadJson(animationFile)
            val spriteSizes = HashMap<String, Pair<Double, Double>>()
            val pages = folder.listFiles { f -> f.name.startsWith("spritemap") && f.name.endsWith(".json") }?.sortedBy { it.name } ?: emptyList()
            for (page in pages) {
                val sprites = loadJson(page).optJSONObject("ATLAS")?.optJSONArray("SPRITES") ?: continue
                for (i in 0 until sprites.length()) {
                    val rec = sprites.optJSONObject(i)?.optJSONObject("SPRITE") ?: continue
                    val name = rec.optString("name", "")
                    if (name.isNotEmpty()) {
                        val rotated = rec.optBoolean("rotated", false)
                        val w = rec.optDouble(if (rotated) "h" else "w", 0.0)
                        val h = rec.optDouble(if (rotated) "w" else "h", 0.0)
                        if (w > 0 && h > 0) spriteSizes[name] = w to h
                    }
                }
            }
            if (spriteSizes.isEmpty()) return null
            val symbols = HashMap<String, JSONObject>()
            animation.optJSONObject("SD")?.optJSONArray("S")?.let { arr ->
                for (i in 0 until arr.length()) {
                    val sym = arr.optJSONObject(i) ?: continue
                    val n = sym.optString("SN", "")
                    val tl = sym.optJSONObject("TL")
                    if (n.isNotEmpty() && tl != null) symbols[n] = tl
                }
            }
            val rootTl = animation.optJSONObject("AN")?.optJSONObject("TL") ?: return null
            fun timelineLength(tl: JSONObject): Int {
                var end = 0
                val layers = tl.optJSONArray("L") ?: return 1
                for (i in 0 until layers.length()) {
                    val frames = layers.optJSONObject(i)?.optJSONArray("FR") ?: continue
                    for (j in 0 until frames.length()) {
                        val fr = frames.optJSONObject(j) ?: continue
                        end = maxOf(end, fr.optInt("I", 0) + fr.optInt("DU", 1).coerceAtLeast(1))
                    }
                }
                return end.coerceAtLeast(1)
            }
            var minX = Double.POSITIVE_INFINITY; var minY = Double.POSITIVE_INFINITY
            var maxX = Double.NEGATIVE_INFINITY; var maxY = Double.NEGATIVE_INFINITY
            fun addRect(name: String, m: Matrix2D) {
                val size = spriteSizes[name] ?: return
                val w = size.first; val h = size.second
                val corners = arrayOf(0.0 to 0.0, w to 0.0, 0.0 to h, w to h)
                for ((x, y) in corners) {
                    val tx = m.a * x + m.c * y + m.tx
                    val ty = m.b * x + m.d * y + m.ty
                    if (tx < minX) minX = tx
                    if (ty < minY) minY = ty
                    if (tx > maxX) maxX = tx
                    if (ty > maxY) maxY = ty
                }
            }
            fun walk(tl: JSONObject, time: Int, parent: Matrix2D, depth: Int) {
                if (depth > 20) return
                val layers = tl.optJSONArray("L") ?: return
                for (li in 0 until layers.length()) {
                    val frames = layers.optJSONObject(li)?.optJSONArray("FR") ?: continue
                    var active: JSONObject? = null
                    for (fi in 0 until frames.length()) {
                        val fr = frames.optJSONObject(fi) ?: continue
                        val start = fr.optInt("I", 0)
                        val duration = fr.optInt("DU", 1).coerceAtLeast(1)
                        if (time >= start && time < start + duration) { active = fr; break }
                    }
                    val fr = active ?: continue
                    val start = fr.optInt("I", 0)
                    val elms = fr.optJSONArray("E") ?: continue
                    for (ei in 0 until elms.length()) {
                        val el = elms.optJSONObject(ei) ?: continue
                        val asi = el.optJSONObject("ASI")
                        if (asi != null) {
                            val spriteName = asi.optString("N", asi.optString("name", ""))
                            if (spriteName.isNotEmpty()) addRect(spriteName, multiply(parent, matrixOf(asi)))
                            continue
                        }
                        val si = el.optJSONObject("SI") ?: continue
                        val symbolName = si.optString("SN", "")
                        val symbolTl = symbols[symbolName] ?: continue
                        val length = timelineLength(symbolTl)
                        val offset = (time - start).coerceAtLeast(0)
                        val first = si.optInt("FF", 0)
                        val childTime = when (si.optString("LP", "LP")) {
                            "SF" -> first
                            "PO" -> (first + offset).coerceAtMost(length - 1)
                            else -> (first + offset) % length
                        }
                        walk(symbolTl, childTime, multiply(parent, matrixOf(si)), depth + 1)
                    }
                }
            }
            val length = timelineLength(rootTl).coerceAtMost(3000)
            for (frame in 0 until length) walk(rootTl, frame, Matrix2D(), 0)
            if (!minX.isFinite() || !minY.isFinite() || !maxX.isFinite() || !maxY.isFinite()) {
                // Last-resort bounds for odd/legacy exporters with an unfamiliar symbol layout.
                val w = spriteSizes.values.maxOfOrNull { it.first } ?: return null
                val h = spriteSizes.values.maxOfOrNull { it.second } ?: return null
                w to h
            } else (maxX - minX).coerceAtLeast(1.0) to (maxY - minY).coerceAtLeast(1.0)
        } catch (_: Exception) { null }
    }

    /** Check image bounds only; decoding every pixel of large atlases defeats fast conversion. */
    fun isPlaceholder(png: File): Boolean {
        if (!png.isFile) return true
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeFile(png.path, bounds)
        return bounds.outWidth <= 4 && bounds.outHeight <= 4
    }

    /** A multi-page atlas is stripped only when every exported page is a placeholder. */
    fun atlasIsPlaceholder(folder: File): Boolean {
        val metas = folder.listFiles { file -> file.name.startsWith("spritemap") && file.name.endsWith(".json") } ?: return true
        if (metas.isEmpty()) return true
        for (json in metas) {
            val imageName = try {
                loadJson(json).optJSONObject("meta")?.optString("image", "").orEmpty()
            } catch (_: Exception) {
                ""
            }
            val pageSprites = try { loadJson(json).optJSONObject("ATLAS")?.optJSONArray("SPRITES")?.length() ?: 0 } catch (_: Exception) { 0 }
            if (pageSprites > 0) {
                val image = File(folder, imageName).takeIf { imageName.isNotEmpty() && it.isFile }
                    ?: File(json.path.removeSuffix(".json") + ".png")
                if (!isPlaceholder(image)) return false
            }
        }
        return true
    }

    /** (frameWidth, frameHeight) of the first Sparrow frame whose name starts with [prefix]. */
    fun sparrowFirstFrameSize(xmls: List<File>, prefix: String): Pair<Int, Int>? {
        for (xml in xmls) sparrowFirstFrameSize(xml, prefix)?.let { return it }
        return null
    }

    fun sparrowFirstFrameSize(xml: File?, prefix: String): Pair<Int, Int>? {
        if (xml == null || !xml.isFile) return null
        val tagRegex = Regex("<SubTexture\\b[^>]*>")
        for (match in tagRegex.findAll(xml.readText())) {
            val tag = match.value
            fun attr(name: String) = Regex("\\b$name=\"([^\"]*)\"").find(tag)?.groupValues?.get(1)
            if ((attr("name") ?: "").startsWith(prefix, ignoreCase = true)) {
                val width = (attr("frameWidth") ?: attr("width"))?.toDoubleOrNull() ?: return null
                val height = (attr("frameHeight") ?: attr("height"))?.toDoubleOrNull() ?: return null
                return width.toInt() to height.toInt()
            }
        }
        return null
    }
}
