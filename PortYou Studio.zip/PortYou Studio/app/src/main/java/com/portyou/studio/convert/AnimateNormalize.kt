package com.portyou.studio.convert

import android.graphics.BitmapFactory
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

/**
 * Rewrites Adobe Animate texture-atlas JSON into the "optimized" short-key layout that Psych Engine's
 * flixel-animate loads (AN / SD / MD, N, STI, SN, TL, L, LN, FR, I, DU, E, SI, ASI, IN, ST, FF, LP, TRP, M3D)
 * and makes every spritemapN.json carry { ATLAS: { SPRITES: [ { SPRITE: {...} } ] }, meta: {...} }.
 *
 * Verified against a known-good Psych atlas: that file passes through unchanged, and a long-form copy of it
 * normalizes back to a byte-equal structure. Reference + test: tools/portyou/animate_norm.py.
 * Keys that have no known short name are kept exactly as they were, never dropped or guessed.
 */
object AnimateNormalize {
    private val TOP = mapOf("ANIMATION" to "AN", "SYMBOL_DICTIONARY" to "SD", "metadata" to "MD")
    private val MAP = mapOf(
        "name" to "N", "StageInstance" to "STI", "SYMBOL_name" to "SN", "TIMELINE" to "TL", "LAYERS" to "L",
        "Layer_name" to "LN", "FRAMES" to "FR", "index" to "I", "duration" to "DU", "elements" to "E",
        "SYMBOL_Instance" to "SI", "ATLAS_SPRITE_instance" to "ASI", "Instance_Name" to "IN", "symbolType" to "ST",
        "firstFrame" to "FF", "loop" to "LP", "transformationPoint" to "TRP", "Matrix3D" to "M3D", "framerate" to "FRT",
        "Symbols" to "S", "color" to "C", "filters" to "F", "Layer_type" to "LT", "Clipped_by" to "CLP",
        "bitmap" to "BM", "tween" to "TWN", "blend" to "B")
    private val SYMTYPE = mapOf("graphic" to "G", "movieclip" to "MC", "button" to "B")
    private val LOOP = mapOf("loop" to "LP", "playonce" to "PO", "singleframe" to "SF")
    private val M3 = listOf("m00", "m01", "m02", "m03", "m10", "m11", "m12", "m13", "m20", "m21", "m22", "m23", "m30", "m31", "m32", "m33")
    private val IDENT = doubleArrayOf(1.0, 0.0, 0.0, 0.0, 0.0, 1.0, 0.0, 0.0, 0.0, 0.0, 1.0, 0.0, 0.0, 0.0, 0.0, 1.0)

    private fun matrix(v: Any?): JSONArray {
        val out = JSONArray()
        if (v is JSONArray && v.length() == 16) { for (i in 0 until 16) out.put(v.optDouble(i, IDENT[i])); return out }
        if (v is JSONObject && v.has("m00")) { M3.forEachIndexed { i, k -> out.put(v.optDouble(k, IDENT[i])) }; return out }
        if (v is JSONObject && v.has("a")) {
            val a = v.optDouble("a", 1.0); val b = v.optDouble("b", 0.0); val c = v.optDouble("c", 0.0); val d = v.optDouble("d", 1.0)
            listOf(a, b, 0.0, 0.0, c, d, 0.0, 0.0, 0.0, 0.0, 1.0, 0.0, v.optDouble("tx", 0.0), v.optDouble("ty", 0.0), 0.0, 1.0).forEach { out.put(it) }
            return out
        }
        IDENT.forEach { out.put(it) }; return out
    }

    private fun conv(o: Any?): Any? = when (o) {
        is JSONArray -> JSONArray().also { r -> for (i in 0 until o.length()) r.put(conv(o.opt(i))) }
        is JSONObject -> {
            val out = JSONObject()
            val it = o.keys()
            while (it.hasNext()) {
                val k = it.next()
                if (k == "DecomposedMatrix" || k == "decomposedMatrix") continue
                val nk = MAP[k] ?: k
                val v = o.get(k)
                when {
                    nk == "M3D" -> out.put(nk, matrix(v))
                    nk == "ST" && v is String -> out.put(nk, SYMTYPE[v] ?: v)
                    nk == "LP" && v is String -> out.put(nk, LOOP[v] ?: v)
                    nk == "TRP" && v is JSONObject -> out.put(nk, JSONObject().put("x", v.optDouble("x", 0.0)).put("y", v.optDouble("y", 0.0)))
                    else -> out.put(nk, conv(v))
                }
            }
            if (out.has("Matrix") && !out.has("M3D")) out.put("M3D", matrix(out.remove("Matrix")))
            out
        }
        else -> o
    }

    /** Returns the normalized Animation.json and whether it had to be converted from the long form. */
    fun animation(j: JSONObject): Pair<JSONObject, Boolean> {
        val isShort = j.has("AN") && j.has("SD")
        val src = if (isShort) j else JSONObject().also { r ->
            val it = j.keys(); while (it.hasNext()) { val k = it.next(); r.put(TOP[k] ?: k, j.get(k)) }
        }
        val r = conv(src) as JSONObject
        if (!r.has("SD")) r.put("SD", JSONObject().put("S", JSONArray()))
        if (!r.has("MD")) r.put("MD", JSONObject().put("FRT", 24.0))
        return r to !isShort
    }

    /** SpriteMap page: always { ATLAS:{SPRITES:[{SPRITE:{name,x,y,w,h,rotated}}]}, meta:{app,version,image,format,size,resolution} }. */
    fun spritemap(j: JSONObject, imageName: String, pngSize: Pair<Int, Int>?): JSONObject {
        val atlas = j.optJSONObject("ATLAS") ?: j
        val raw = atlas.optJSONArray("SPRITES") ?: JSONArray()
        val sprites = JSONArray()
        for (i in 0 until raw.length()) {
            val e = raw.optJSONObject(i) ?: continue
            val r = e.optJSONObject("SPRITE") ?: e
            sprites.put(JSONObject().put("SPRITE", JSONObject().put("name", r.opt("name").toString())
                .put("x", r.opt("x")).put("y", r.opt("y")).put("w", r.opt("w")).put("h", r.opt("h")).put("rotated", r.optBoolean("rotated", false))))
        }
        val meta = JSONObject(j.optJSONObject("meta")?.toString() ?: "{}")
        meta.put("image", imageName)
        if (!meta.has("app")) meta.put("app", "Adobe Animate")
        if (!meta.has("version")) meta.put("version", "22.0.8.217")
        if (!meta.has("format")) meta.put("format", "RGBA8888")
        if (!meta.has("resolution")) meta.put("resolution", "1")
        if (pngSize != null) meta.put("size", JSONObject().put("w", pngSize.first).put("h", pngSize.second))
        else if (!meta.has("size")) meta.put("size", JSONObject().put("w", 0).put("h", 0))
        return JSONObject().put("ATLAS", JSONObject().put("SPRITES", sprites)).put("meta", meta)
    }

    private fun pngSize(f: File): Pair<Int, Int>? {
        if (!f.isFile) return null
        val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeFile(f.path, o)
        return if (o.outWidth > 0 && o.outHeight > 0) o.outWidth to o.outHeight else null
    }

    private fun load(f: File) = JSONObject(f.readText().removePrefix("\uFEFF"))

    /** Checks that every symbol instance and sprite reference resolves; returns human-readable problems. */
    fun validate(anim: JSONObject, spriteNames: Set<String>): List<String> {
        val errs = ArrayList<String>()
        val syms = HashSet<String>()
        val sa = anim.optJSONObject("SD")?.optJSONArray("S") ?: JSONArray()
        for (i in 0 until sa.length()) syms.add(sa.getJSONObject(i).optString("SN"))
        fun walk(tl: JSONObject?, where: String) {
            val ls = tl?.optJSONArray("L") ?: return
            for (a in 0 until ls.length()) { val fr = ls.getJSONObject(a).optJSONArray("FR") ?: continue
                for (b in 0 until fr.length()) { val es = fr.getJSONObject(b).optJSONArray("E") ?: continue
                    for (c in 0 until es.length()) { val e = es.getJSONObject(c)
                        e.optJSONObject("SI")?.let { si ->
                            if (si.optString("SN") !in syms) errs.add("$where: missing symbol ${si.optString("SN")}")
                            if ((si.optJSONArray("M3D")?.length() ?: 0) != 16) errs.add("$where: bad M3D")
                        }
                        e.optJSONObject("ASI")?.let { if (it.optString("N") !in spriteNames) errs.add("$where: missing sprite ${it.optString("N")}") }
                    } } }
        }
        walk(anim.optJSONObject("AN")?.optJSONObject("TL"), "AN")
        for (i in 0 until sa.length()) walk(sa.getJSONObject(i).optJSONObject("TL"), sa.getJSONObject(i).optString("SN"))
        return errs.distinct().take(8)
    }

    /** Walks a converted mod and rewrites every Animate atlas folder in place. */
    fun run(outDir: File, warn: (String) -> Unit, method: (String) -> Unit) {
        val animFiles = outDir.walkTopDown().filter { it.isFile && it.name == "Animation.json" }.toList()
        var converted = 0
        for (af in animFiles) {
            try {
                val dir = af.parentFile ?: continue
                val (anim, wasLong) = animation(load(af))
                if (wasLong) converted++
                val pages = dir.listFiles { f -> f.isFile && f.name.startsWith("spritemap") && f.name.endsWith(".json") }?.sortedBy { it.name } ?: emptyList()
                val names = HashSet<String>()
                for (pf in pages) {
                    val raw = load(pf)
                    val stem = pf.name.removeSuffix(".json")
                    val declared = raw.optJSONObject("meta")?.optString("image").orEmpty()
                    val png = File(dir, "$stem.png").takeIf { it.isFile } ?: File(dir, declared).takeIf { declared.isNotEmpty() && it.isFile }
                    val norm = spritemap(raw, png?.name ?: "$stem.png", png?.let { pngSize(it) })
                    pf.writeText(norm.toString(1))
                    val sp = norm.getJSONObject("ATLAS").getJSONArray("SPRITES")
                    for (i in 0 until sp.length()) names.add(sp.getJSONObject(i).getJSONObject("SPRITE").getString("name"))
                }
                af.writeText(anim.toString())   // compact like Animate's optimized export
                val errs = validate(anim, names)
                if (errs.isNotEmpty()) warn("Animate atlas ${dir.name}: ${errs.joinToString("; ")}")
            } catch (e: Exception) {
                warn("Animate atlas ${af.parentFile?.name}: could not normalize (${e.message}); left as it was")
            }
        }
        if (animFiles.isNotEmpty()) method("Animate atlases normalized to the optimized Psych layout (${animFiles.size} atlas, $converted converted from the long form); sprite references validated")
    }
}
