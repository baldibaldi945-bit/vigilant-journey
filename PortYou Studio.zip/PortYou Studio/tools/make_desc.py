#!/usr/bin/env python3
"""Builds desc_en / desc_pt / desc_ja in the style of desc_ar.png (purple 170,0,255, transparent, 365x913)."""
import os, re, sys
from PIL import Image, ImageDraw, ImageFont, ImageFilter
OUT = sys.argv[1] if len(sys.argv) > 1 else 'app/src/main/assets/ui'
W, H = 365, 913; PURPLE = (170, 0, 255, 255)
CR = '/usr/share/fonts/truetype/google-fonts/ofl/comicrelief/ComicRelief-Regular.ttf'
CRB = '/usr/share/fonts/truetype/google-fonts/ofl/comicrelief/ComicRelief-Bold.ttf'
JP = '/usr/share/fonts/opentype/noto/NotoSansCJK-Medium.ttc'
JPB = '/usr/share/fonts/opentype/noto/NotoSansCJK-Bold.ttc'
TEXT = {
 'en': ("Welcome to my app! Its main job is porting V-Slice and Funky Maker mods to Psych Engine, and it's Arab-made, heheh. Did you expect Arabs to fail, right? Swallow the shock hahaha. Anyway, it works offline, it adds credits to every mod, and it will help you a lot if you want to try it. The max file size is", "2GB", CR, CRB, 0),
 'pt': ("Bem-vindo ao meu app! A função principal dele é portar mods de V-Slice e Funky Maker para o Psych Engine, e foi feito por um árabe, hehehe. Você achou que os árabes iam fracassar, né? Engole o choque hahaha. Enfim, ele funciona offline, coloca os créditos em todo mod e vai te ajudar muito se quiser testar. O tamanho máximo dos arquivos é", "2GB", CR, CRB, 0),
 'ja': ("僕のアプリへようこそ！主な機能は V-Slice と Funky Maker のMODを Psych Engine に移植することで、アラブ人製なんだ、へへへ。アラブ人は失敗すると思ってた？ショックを飲み込んでねwww とにかくオフラインで動いて、どのMODにもクレジットが付くし、試したらきっと役に立つよ。ファイルサイズの上限は", "2GB", JP, JPB, 2),
}
def wrap(d, s, font, maxw, cjk):
    toks = re.findall(r"[A-Za-z0-9\-' ]+|.", s) if cjk else s.split(' ')
    lines, cur = [], ''
    for t in toks:
        trial = cur + t if cjk else (cur + ' ' + t if cur else t)
        if d.textlength(trial, font=font) <= maxw: cur = trial
        else: lines.append(cur); cur = t
    lines.append(cur); return lines
def ring(mask):
    outer = mask.filter(ImageFilter.MaxFilter(3)); inner = mask.filter(ImageFilter.MinFilter(5))
    return Image.eval(Image.composite(Image.new('L', mask.size, 255), Image.new('L', mask.size, 0), outer), lambda v: v) if False else \
        Image.fromarray(__import__('numpy').clip(__import__('numpy').array(outer, dtype=int) - __import__('numpy').array(inner, dtype=int), 0, 255).astype('uint8'))
for lang, (body, big, f1, f2, idx) in TEXT.items():
    cjk = lang == 'ja'; m = 6
    for size in range(60, 14, -1):
        font = ImageFont.truetype(f1, size, index=idx); bigf = ImageFont.truetype(f2, size, index=idx)
        d = ImageDraw.Draw(Image.new('L', (W, H)))
        lines = wrap(d, body, font, W - 2 * m, cjk); lh = int(size * 1.32)
        last_w = d.textlength(lines[-1] + ' ', font=font) + d.textlength(big, font=bigf)
        if last_w > W - 2 * m: lines.append(''); 
        if len(lines) * lh + 8 <= H: break
    img = Image.new('RGBA', (W, H), (0, 0, 0, 0)); dr = ImageDraw.Draw(img)
    total = len(lines) * lh; y = (H - total) // 2
    for i, ln in enumerate(lines):
        if i == len(lines) - 1:
            pre = ln + (' ' if ln and not cjk else '')
            dr.text((m, y), pre, font=font, fill=PURPLE)
            x = m + dr.textlength(pre, font=font)
            mask = Image.new('L', (W, H), 0); ImageDraw.Draw(mask).text((x, y), big, font=bigf, fill=255)
            img.paste(Image.new('RGBA', (W, H), PURPLE), (0, 0), ring(mask))
        else: dr.text((m, y), ln, font=font, fill=PURPLE)
        y += lh
    img.save(os.path.join(OUT, f'desc_{lang}.png'), optimize=True); print(lang, size, len(lines))
