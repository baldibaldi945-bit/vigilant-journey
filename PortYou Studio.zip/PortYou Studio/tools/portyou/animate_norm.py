"""Reference normaliser: any Adobe Animate texture-atlas Animation.json -> the optimized short form
that Psych Engine's flixel-animate loads (same layout as the user's working example)."""
import json, copy

TOP = {"ANIMATION":"AN","SYMBOL_DICTIONARY":"SD","metadata":"MD"}
MAP = {"name":"N","StageInstance":"STI","SYMBOL_name":"SN","TIMELINE":"TL","LAYERS":"L","Layer_name":"LN",
       "FRAMES":"FR","index":"I","duration":"DU","elements":"E","SYMBOL_Instance":"SI","ATLAS_SPRITE_instance":"ASI",
       "Instance_Name":"IN","symbolType":"ST","firstFrame":"FF","loop":"LP","transformationPoint":"TRP",
       "Matrix3D":"M3D","framerate":"FRT","Symbols":"S","color":"C","filters":"F","Layer_type":"LT","Clipped_by":"CLP",
       "bitmap":"BM","tween":"TWN","blend":"B"}
SYMTYPE = {"graphic":"G","movieclip":"MC","button":"B","G":"G","MC":"MC","B":"B"}
LOOP = {"loop":"LP","playonce":"PO","singleframe":"SF","LP":"LP","PO":"PO","SF":"SF"}
M3 = ["m00","m01","m02","m03","m10","m11","m12","m13","m20","m21","m22","m23","m30","m31","m32","m33"]
DROP = {"DecomposedMatrix","decomposedMatrix"}
IDENT = [1,0,0,0, 0,1,0,0, 0,0,1,0, 0,0,0,1]

def matrix(v):
    if isinstance(v, list) and len(v) == 16: return [float(x) for x in v]
    if isinstance(v, dict):
        if "m00" in v: return [float(v.get(k, IDENT[i])) for i,k in enumerate(M3)]
        if "a" in v:  # 2D matrix
            a,b,c,d,tx,ty = (float(v.get(k, dflt)) for k,dflt in (("a",1),("b",0),("c",0),("d",1),("tx",0),("ty",0)))
            return [a,b,0,0, c,d,0,0, 0,0,1,0, tx,ty,0,1]
    return list(map(float, IDENT))

def conv(o, report):
    if isinstance(o, list): return [conv(x, report) for x in o]
    if not isinstance(o, dict): return o
    out = {}
    for k, v in o.items():
        if k in DROP: continue
        nk = MAP.get(k, k)
        if nk != k: report["renamed"].add(k)
        if nk == "M3D": out[nk] = matrix(v)
        elif nk == "ST" and isinstance(v, str): out[nk] = SYMTYPE.get(v, v)
        elif nk == "LP" and isinstance(v, str): out[nk] = LOOP.get(v, v)
        elif nk == "TRP" and isinstance(v, dict): out[nk] = {"x": float(v.get("x", 0)), "y": float(v.get("y", 0))}
        else: out[nk] = conv(v, report)
    # 2D "Matrix" on an instance -> M3D (only when no M3D already)
    if "Matrix" in out and "M3D" not in out:
        out["M3D"] = matrix(out.pop("Matrix"))
    return out

def normalize_animation(j):
    report = {"renamed": set(), "form": "short"}
    if "AN" in j and "SD" in j: 
        r = conv(j, report); r.setdefault("MD", {"FRT": 24.0}); return r, report
    report["form"] = "long"
    j2 = {TOP.get(k, k): v for k, v in j.items()}
    r = conv(j2, report)
    r.setdefault("SD", {"S": []}); r.setdefault("MD", {"FRT": 24.0})
    return r, report

def normalize_spritemap(j, image_name, png_size=None):
    sprites = None
    atlas = j.get("ATLAS", j)
    raw = atlas.get("SPRITES") if isinstance(atlas, dict) else None
    if raw is None and isinstance(j.get("frames"), (list, dict)):  # generic json-array/hash exports
        fr = j["frames"]; items = fr if isinstance(fr, list) else [dict(v, filename=k) for k, v in fr.items()]
        raw = [{"SPRITE": {"name": str(it.get("filename", i)).rsplit(".",1)[0], "x": it["frame"]["x"], "y": it["frame"]["y"],
                           "w": it["frame"]["w"], "h": it["frame"]["h"], "rotated": bool(it.get("rotated", False))}} for i, it in enumerate(items)]
    sprites = []
    for s in raw or []:
        r = s.get("SPRITE", s)
        sprites.append({"SPRITE": {"name": str(r["name"]), "x": r["x"], "y": r["y"], "w": r["w"], "h": r["h"], "rotated": bool(r.get("rotated", False))}})
    meta = dict(j.get("meta", {}))
    meta["image"] = image_name
    meta.setdefault("app", "Adobe Animate"); meta.setdefault("version", "22.0.8.217"); meta.setdefault("format", "RGBA8888")
    meta.setdefault("resolution", "1")
    if png_size: meta["size"] = {"w": png_size[0], "h": png_size[1]}
    meta.setdefault("size", {"w": 0, "h": 0})
    return {"ATLAS": {"SPRITES": sprites}, "meta": meta}

def validate(anim, sprites_names):
    errs = []
    syms = {s["SN"] for s in anim["SD"]["S"]}
    def walk(tl, where):
        for L in tl.get("L", []):
            for F in L.get("FR", []):
                for E in F.get("E", []):
                    if "SI" in E:
                        if E["SI"]["SN"] not in syms: errs.append(f"{where}: missing symbol {E['SI']['SN']}")
                        if len(E["SI"].get("M3D", [])) != 16: errs.append(f"{where}: bad M3D")
                    if "ASI" in E and E["ASI"]["N"] not in sprites_names: errs.append(f"{where}: missing sprite {E['ASI']['N']}")
    walk(anim["AN"]["TL"], "AN")
    for s in anim["SD"]["S"]: walk(s["TL"], s["SN"])
    return errs
